#!/bin/bash
sudo apt-get update
sudo apt-get install python3
sudo apt-get install python3-pip
pip3 install pymysql
python3 crud.py
